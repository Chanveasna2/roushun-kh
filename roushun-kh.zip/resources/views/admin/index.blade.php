
@extends('admin.fragement.layout')


    @section('content1')

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="/admin">Dashboard</a>
            </li>
          </ol>

          <!-- Page Content -->
          <h1>Welcome to Admin Panel Roushun Cambodia</h1>
          <hr>
          <p></p>

        </div>
        <!-- /.container-fluid -->



    @stop
