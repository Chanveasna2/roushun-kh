<?php $__env->startSection('content1'); ?>

    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.blade.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Blank Page</li>
        </ol>

        <!-- Page Content -->
        <?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div>
            <a href="<?php echo e(route('promotions.index')); ?>" class="color:white;"><button class="btn btn-primary">All Promotions</button></a>
        </div>
        <div class="row">
            <div class="col-9">
                <?php echo Form::model($promotions,['method'=>'PATCH', 'action'=> ['PromotionController@update',$promotions->id],'files'=>true]); ?>


                <div class="form-group">
                    <?php echo Form::label('promo_name','Promotion Name:'); ?>

                    <?php echo Form::text('promo_name',null,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('desc','Description:'); ?>

                    <?php echo Form::text('desc',null,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::submit('Confirm',['class'=>'btn btn-primary']); ?>

                </div>

                <?php echo Form::close(); ?>


                <?php echo Form::open(['method'=>'DELETE','action'=>['PromotionController@destroy',$promotions->id]]); ?>

                <div class="form-group">
                    <?php echo Form::submit('DELETE',['class'=>'btn btn-danger']); ?>

                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>