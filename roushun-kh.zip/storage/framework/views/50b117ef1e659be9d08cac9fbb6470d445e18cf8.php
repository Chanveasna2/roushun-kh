<?php $__env->startSection('content1'); ?>
    <div class="container" id="aboutus">
        <div class="row">
            <div class="col-md-7">
                <?php $__currentLoopData = $sys_static; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sys_statics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h4 class="title"><?php echo e($sys_statics->static_name); ?></h4>
                <p class="about_company"><?php echo e($sys_statics->static_value_first); ?></p>

            </div>
            <div class="col-md-5" id="about1">
                <img src="<?php echo e($sys_statics->photo->file); ?>" class="image1">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="container" id="mission">
        <div class="row">
            <?php $__currentLoopData = $sys_static2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sys_statics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-5" id="about2">
                <img src="<?php echo e($sys_statics->photo->file); ?>"  class="image2">
            </div>
            <div class="col-md-7">

                <h4 class="title" id="title_vision"><?php echo e($sys_statics->static_name); ?></h4>
                <p class="vision"><?php echo e($sys_statics->static_value_first); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $sys_static3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sys_statics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h4 class="title"><?php echo e($sys_statics->static_name); ?></h4>
                <p class="mission"><?php echo e($sys_statics->static_value_first); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>