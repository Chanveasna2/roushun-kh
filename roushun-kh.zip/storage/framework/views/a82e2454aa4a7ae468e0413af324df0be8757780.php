<?php $__env->startSection('content1'); ?>

    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.blade.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Blank Page</li>
        </ol>

        <!-- Page Content -->
        <?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div>
            <a href="<?php echo e(route('products.index')); ?>" class="color:white;"><button class="btn btn-primary">All Products</button></a>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12">
                <img src="<?php echo e($products->photo?$products->photo->file:'https://via.placeholder.com/400x400'); ?>" alt="" class="img-fluid" style="margin-top: 140px" height="200px">
            </div>
            <div class="col-9">
                <?php echo Form::model($products,['method'=>'PATCH', 'action'=> ['ProductController@update',$products->id],'files'=>true]); ?>


                <div class="form-group">
                    <?php echo Form::label('pro_name','Product Name:'); ?>

                    <?php echo Form::text('pro_name',null,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('pro_code','Product Code:'); ?>

                    <?php echo Form::text('pro_code',null,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('desc','Description:'); ?>

                    <?php echo Form::text('desc',null,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('prices','Price:'); ?>

                    <?php echo Form::text('prices',null,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('category_id','Category:'); ?>

                    <?php echo Form::select('category_id',[''=>'Choose Option'] + $category->pluck('category_name','id')->toArray(),null,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('isPop','Popular:'); ?>

                    <?php echo Form::text('isPop',null,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('photo_id','Photo:'); ?>

                    <?php echo Form::file('photo_id',null,['class'=>'form-control']); ?>

                </div>


                <div class="form-group">
                    <?php echo Form::submit('Confirm',['class'=>'btn btn-primary']); ?>

                </div>


                <?php echo Form::close(); ?>


                <?php echo Form::open(['method'=>'DELETE','action'=>['ProductController@destroy',$products->id]]); ?>

                <div class="form-group">
                    <?php echo Form::submit('DELETE',['class'=>'btn btn-danger']); ?>

                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>