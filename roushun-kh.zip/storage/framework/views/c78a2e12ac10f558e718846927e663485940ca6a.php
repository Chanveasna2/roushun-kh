<!DOCTYPE html>
<html lang="en">
<title>Roushun Cambodia</title>

<head>

    <?php echo $__env->make('frontend.fragement.style', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>
<body>
    <div class="container" style="height: 100px">
        <div class="row" id="header">
            <div id="logo">
                <a href="/"><img src="/images/logo.png"></a>
            </div>
            <div id="adv">
                <img src="/images/adv.gif">
            </div>
        </div>
    </div><!----end logo----->


   <!---------Navbar--------------->
    <div class="container-fluid color-background" id="navbar-menu">
        <div class="container">
            <!-- menu navbar -->
            <nav class="navbar navbar-expand-lg navbar-light">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
                    <a class="navbar-brand fas fa-home" href="/" style="color: white;"></a>
                    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/about-products')); ?>">អំពីផលិតផល<span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/product-category')); ?>">ប្រភេទផលិតផល</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/distribution-network')); ?>">ដៃគូចែកចាយ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/about-us')); ?>">អំពីក្រុមហ៊ុន</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/contact-us')); ?>">ទំនាក់ទំនង</a>
                        </li>

                    </ul>
                    <form class="form-inline my-2 my-lg-0">
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                    </form>
                </div>
            </nav>
            <!-- end navbar -->

        </div>
    </div>
    <!--------end container-fluid Navbar--------------->

    <?php echo $__env->yieldContent('content1'); ?>


    <!-- Footer -->
    <section id="footer" >
        <div class="container" style="margin-top: -40px" >
            <div class="row text-center text-xs-center text-sm-left text-md-left">
                <!-- <div class="col-xs-12 col-sm-4 col-md-4">
                    <h5>ព័ត៌មានថ្មីៗ & សេចក្តីប្រកាស</h5>
                    <p style="color: white;">បច្ចុប្បន្នពុំទាន់មានព័ត៌មានថ្មីៗនោះទេ
                        សូមចូលមកមើលម្តងទៀតនៅពេលខាងមុខនេះ។</p>
                </div> -->
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <h5>អំពីក្រុមហ៊ុន</h5>
                    <p style="color: white;">Rouhun Cambodia.</p>
                    
                        
                        
                        
                        
                        
                    
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <?php $__currentLoopData = $sys_s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5><?php echo e($sys->static_value_first); ?>៖</h5>
                    <p style="color: white;"><?php echo e($sys->static_value_second); ?></p>
                    <p style="color: white;"><?php echo e($sys->static_value_third); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
                    <ul class="list-unstyled list-inline social text-center">
                        <li class="list-inline-item"><a href="https://www.facebook.com/roushuncambodia" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li>
                        <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
                        <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li>
                        <li class="list-inline-item"><a href="javascript:void();" target="_blank"><i class="fa fa-envelope"></i></a></li>
                    </ul>
                </div>
                </hr>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
                    <p class="h6">© 2018, Roushun Cambodia, All Rights Reserved.</p>
                </div>
                </hr>
            </div>
        </div>
    </section>
    <!-- ./Footer -->


<?php echo $__env->make('frontend.fragement.footerjs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
