<?php $__env->startSection('content1'); ?>

    <div class="container">
        <div class="col-md-12" style="margin-top: 30px">
            <div class="row">
                <h4 class="title">ដៃគូចែកចាយ</h4>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="col-md-12" style="margin-bottom: 30px">
            <div class="row">
                <img src="/images/distribution-map.png" style="width: 80%;height: 80%;margin-left: auto;margin-right: auto">
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>