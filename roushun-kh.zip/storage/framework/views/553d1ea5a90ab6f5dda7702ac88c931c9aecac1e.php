<?php $__env->startSection('content1'); ?>


    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="/admin/products">Product</a>
            </li>
            
        </ol>
        <?php if(Session::has('deleted_user')): ?>
                <p class="bg-danger"><?php echo e(session('deleted_user')); ?></p>
            <?php endif; ?>
        <!-- Page Content -->
        <a href="<?php echo e(route('products.create')); ?>" class="color:white;"><button class="btn btn-primary">Create</button></a>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Product Name</th>
                <th scope="col">By User</th>
                <th scope="col">Product Code</th>
                <th scope="col">Description</th>
                <th scope="col">Prices</th>
                <th scope="col">Category</th>
                <th scope="col">Popular</th>
                <th scope="col">Images</th>
                <th scope="col">Action</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($product->id); ?></th>
                    <td><?php echo e($product->pro_name); ?></td>
                    <td><?php echo e($product->user->name); ?></td>
                    <td><?php echo e($product->pro_code); ?></td>
                    <td><?php echo e(str_limit($product->desc,20)); ?></td>
                    <td>$<?php echo e($product->prices); ?></td>
                    <td><?php echo e($product->category->category_name); ?></td>
                    <td><?php echo e($product->isPop); ?></td>
                    <td><img height="50px;" src="<?php echo e($product->photo?$product->photo->file:'https://via.placeholder.com/400x400'); ?>" alt=""></td>

                    <td>
                        <a href="<?php echo e(route('products.edit',$product->id)); ?>"><i class="btn btn-primary fas fa-edit"></i></a>

                    </td>
                    <td>
                        <?php echo Form::open(['method'=>'DELETE','action'=>['ProductController@destroy',$product->id]]); ?>

                        <div class="form-group ">
                            
                            <button class="btn btn-danger fas fa-trash-alt" type="submit" value=""></button>
                        </div>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>


    </div>
    <!-- /.container-fluid -->
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>