<?php $__env->startSection('content1'); ?>





    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.blade.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Blank Page</li>
        </ol>

        <!-- Page Content -->
        <?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <a href="<?php echo e(route('sys_statics.index')); ?>" class="color:white;"><button class="btn btn-primary">All User</button></a>

            <?php echo Form::model($sys_statics ,['method'=>'PATCH', 'action'=> ['SysStaticController@update',$sys_statics->id],'files'=>true]); ?>


            <div class="form-group">
                <?php echo Form::label('static_name','Static Name:'); ?>

                <?php echo Form::text('static_name',null,['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('static_value','Static Value:'); ?>

                <?php echo Form::text('static_value',null,['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::submit('Confirm',['class'=>'btn btn-primary']); ?>

            </div>


            <?php echo Form::close(); ?>


            <?php echo Form::open(['method'=>'DELETE','action'=>['SysStaticController@destroy',$sys_statics->id]]); ?>

                <div class="form-group">
                    <?php echo Form::submit('DELETE',['class'=>'btn btn-danger']); ?>

                </div>
            <?php echo Form::close(); ?>


    </div>
    <!-- /.container-fluid -->

    </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>