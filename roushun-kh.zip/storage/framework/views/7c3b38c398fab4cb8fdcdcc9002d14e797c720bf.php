<?php $__env->startSection('content1'); ?>





    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.blade.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Blank Page</li>
        </ol>

        <!-- Page Content -->
        <?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <a href="<?php echo e(route('users.index')); ?>" class="color:white;"><button class="btn btn-primary">All User</button></a>

            <?php echo Form::model($users ,['method'=>'PATCH', 'action'=> ['AdminUserController@update',$users->id],'files'=>true]); ?>


            <div class="form-group">
                <?php echo Form::label('name','Username:'); ?>

                <?php echo Form::text('name',null,['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('email','Email:'); ?>

                <?php echo Form::email('email',null,['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('password','Password:'); ?>

                <?php echo Form::password('password',['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('role_id','Role:'); ?>

                <?php echo Form::select('role_id',[''=>'Choose Option'] + $roles->pluck('name','id')->toArray(),null,['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('isActive','Status'); ?>

                <?php echo Form::select('isActive',array(1=>'Active',0=>'Not Active'),null,['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('photo_id','Photo:'); ?>

                <?php echo Form::file('photo_id',null,['class'=>'form-control']); ?>

                <img src="<?php echo e($users->photo?$users->photo->file:'https://via.placeholder.com/400x400'); ?>" alt="" class=" img-rounded" height="100px">
            </div>
            <div class="form-group">
                <?php echo Form::submit('Confirm',['class'=>'btn btn-primary']); ?>

            </div>


            <?php echo Form::close(); ?>


            <?php echo Form::open(['method'=>'DELETE','action'=>['AdminUserController@destroy',$users->id]]); ?>

                <div class="form-group">
                    <?php echo Form::submit('DELETE',['class'=>'btn btn-danger']); ?>

                </div>
            <?php echo Form::close(); ?>


    </div>
    <!-- /.container-fluid -->

    </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>