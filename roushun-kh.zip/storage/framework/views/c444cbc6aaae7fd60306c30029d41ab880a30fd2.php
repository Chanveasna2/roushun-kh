<?php $__env->startSection('content1'); ?>


    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.blade.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Blank Page</li>
        </ol>
        <?php if(Session::has('deleted_user')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('deleted_user')); ?>

            </div>
            <?php endif; ?>
        <!-- Page Content -->
        <a href="<?php echo e(route('promotions.create')); ?>" class="color:white;"><button class="btn btn-primary">Create</button></a>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Promotion Name</th>
                <th scope="col">Description</th>
                <th scope="col">Poster</th>
                <th scope="col">Created</th>
                <th scope="col">Updated</th>
                <th scope="col">Action</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($promotion->id); ?></th>
                    <td><?php echo e($promotion->promo_name); ?></td>
                    <td><?php echo e($promotion->desc); ?></td>
                    <td><?php echo e($promotion->user->name); ?></td>
                    <td><?php echo e($promotion->created_at->diffForHumans()); ?></td>
                    <td><?php echo e($promotion->updated_at); ?></td>
                    <td>
                        <a href="<?php echo e(route('promotions.edit',$promotion->id)); ?>"><i class="btn btn-primary fas fa-edit"></i></a>

                    </td>
                    <td>
                        <?php echo Form::open(['method'=>'DELETE','action'=>['PromotionController@destroy',$promotion->id]]); ?>

                        <div class="form-group ">
                            
                            <button class="btn btn-danger fas fa-trash-alt" type="submit" value=""></button>
                        </div>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>


    </div>
    <!-- /.container-fluid -->
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>