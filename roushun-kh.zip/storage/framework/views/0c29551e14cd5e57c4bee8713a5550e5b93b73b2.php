<?php $__env->startSection('content1'); ?>

    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.blade.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Blank Page</li>
        </ol>

        <!-- Page Content -->
        <?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <a href="<?php echo e(route('promotions.index')); ?>" class="color:white;"><button class="btn btn-primary">Return to Promotion List</button></a>

        <?php echo Form::open(['method'=>'POST', 'action'=> 'PromotionController@store','files'=>true]); ?>


                <div class="form-group">
                    <?php echo Form::label('promo_name','Promotion Name:'); ?>

                    <?php echo Form::text('promo_name',null,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('desc','Description:'); ?>

                    <?php echo Form::text('desc',null,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::submit('Create',['class'=>'btn btn-primary']); ?>

                </div>


        <?php echo Form::close(); ?>


    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>