<?php $__env->startSection('content1'); ?>

    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.blade.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Blank Page</li>
        </ol>

        <!-- Page Content -->
        <?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <a href="<?php echo e(route('slide_shows.index')); ?>" class="color:white;"><button class="btn btn-primary">All Slide Show</button></a>

        <?php echo Form::open(['method'=>'POST', 'action'=> 'SlideShowController@store','files'=>true]); ?>


        <div class="form-group">
            <?php echo Form::label('slide_name','Slide Name:'); ?>

            <?php echo Form::text('slide_name',null,['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('order','Order Name:'); ?>

            <?php echo Form::text('order',null,['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('photo_id','Photo:'); ?>

            <?php echo Form::file('photo_id',null,['class'=>'form-control']); ?>

        </div>


        <div class="form-group">
            <?php echo Form::submit('Create',['class'=>'btn btn-primary']); ?>

        </div>


        <?php echo Form::close(); ?>


    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>