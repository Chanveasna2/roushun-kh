<?php $__env->startSection('content1'); ?>


    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.blade.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Blank Page</li>
        </ol>
        <?php if(Session::has('deleted_user')): ?>
                <p class="bg-danger"><?php echo e(session('deleted_user')); ?></p>
            <?php endif; ?>
        <!-- Page Content -->
        <a href="<?php echo e(route('sys_statics.create')); ?>" class="color:white;"><button class="btn btn-primary">Create</button></a>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable">
                    <thead class="">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">S Name</th>
                        <th scope="col">Value1</th>
                        <th scope="col">Value2</th>
                        <th scope="col">Value3</th>
                        <th scope="col">Value4</th>
                        <th scope="col">File</th>
                        <th scope="col">Created</th>
                        <th scope="col">Updated</th>
                        <th scope="col">Action</th>
                        <th scope="col"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $sys_statics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sys_static): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($sys_static->id); ?></th>
                            <td><?php echo e($sys_static->static_name); ?></td>
                            <td><?php echo e(str_limit($sys_static->static_value_first,10)); ?></td>
                            <td><?php echo e(str_limit($sys_static->static_value_second,10)); ?></td>
                            <td><?php echo e(str_limit($sys_static->static_value_third,10)); ?></td>
                            <td><?php echo e(str_limit($sys_static->static_value_forth,10)); ?></td>
                            <td><img height="50px;" src="<?php echo e($sys_static->photo?$sys_static->photo->file:'https://via.placeholder.com/400x400'); ?>" alt=""></td>
                            <td><?php echo e($sys_static->created_at->diffForHumans()); ?></td>
                            <td><?php echo e($sys_static->updated_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('sys_statics.edit',$sys_static->id)); ?>"><i class="btn btn-primary fas fa-edit"></i></a>

                            </td>
                            <td>
                                <?php echo Form::open(['method'=>'DELETE','action'=>['SysStaticController@destroy',$sys_static->id]]); ?>

                                <div class="form-group ">
                                    
                                    <button class="btn btn-danger fas fa-trash-alt" type="submit" value=""></button>
                                </div>
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>


    </div>
    <!-- /.container-fluid -->
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>