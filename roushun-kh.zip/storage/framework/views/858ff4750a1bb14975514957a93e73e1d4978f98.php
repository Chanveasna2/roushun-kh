<?php $__env->startSection('content1'); ?>


    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.blade.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Blank Page</li>
        </ol>
        <?php if(Session::has('deleted_user')): ?>
                <p class="bg-danger"><?php echo e(session('deleted_user')); ?></p>
            <?php endif; ?>
        <!-- Page Content -->
        <a href="<?php echo e(route('users.create')); ?>" class="color:white;"><button class="btn btn-primary">Create</button></a>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Photo</th>
                <th scope="col">Username</th>
                <th scope="col">Email</th>
                <th scope="col">Role</th>
                <th scope="col">Status</th>
                <th scope="col">Created</th>
                <th scope="col">Updated</th>
                <th scope="col">Action</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($users->id); ?></th>
                    <td><img height="50px;" src="<?php echo e($users->photo?$users->photo->file:'https://via.placeholder.com/400x400'); ?>" alt=""></td>
                    <td><?php echo e($users->name); ?></td>
                    <td><?php echo e($users->email); ?></td>
                    <td><?php echo e($users->role->name); ?></td>
                    <td><?php echo e($users->isActive==1?'Active':'Not Active'); ?></td>
                    <td><?php echo e($users->created_at->diffForHumans()); ?></td>
                    <td><?php echo e($users->updated_at); ?></td>
                    <td>
                        <a href="<?php echo e(route('users.edit',$users->id)); ?>"><i class="btn btn-primary fas fa-edit"></i></a>

                    </td>
                    <td>
                        <?php echo Form::open(['method'=>'DELETE','action'=>['AdminUserController@destroy',$users->id]]); ?>

                        <div class="form-group ">
                            
                            <button class="btn btn-danger fas fa-trash-alt" type="submit" value=""></button>
                        </div>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>


    </div>
    <!-- /.container-fluid -->
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>