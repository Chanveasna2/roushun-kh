    <?php $__env->startSection('content1'); ?>

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="/admin">Dashboard</a>
            </li>
          </ol>

          <!-- Page Content -->
          <h1>Welcome to Admin Panel Roushun Cambodia</h1>
          <hr>
          <p></p>

        </div>
        <!-- /.container-fluid -->



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.fragement.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>