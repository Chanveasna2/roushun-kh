<?php

namespace App\Http\Controllers;

use App\SysStatic;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class SysStaticController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $sys_statics = SysStatic::all();

        return view('admin.sys_statics.index',compact('sys_statics'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('admin.sys_statics.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $input = $request->all();

        SysStatic::create($input);

        return redirect('admin/sys_statics');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $sys_statics = SysStatic::findOrFail($id);

        return view('admin.sys_statics.edit',compact('sys_statics'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $sys_statics = SysStatic::findOrFail($id);

        $input =$request->all();

        $sys_statics->update($input);

        return redirect('admin/sys_statics');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $sys_statics = SysStatic::findOrFail($id);

        $sys_statics->delete();

        Session::flash('deleted_user','Sys Static Deleted');

        return redirect('admin/sys_statics');
    }
}
